<?php get_header(); ?>
<div class="container" style="text-align:center;padding:6rem 0;">
    <h1 style="font-size:3rem;font-weight:700;margin-bottom:1.5rem;">404</h1>
    <div style="font-size:1.5rem;margin-bottom:2.5rem;">Page not found</div>
    <a href="<?php echo esc_url(home_url('/')); ?>" class="card-link" style="font-size:1.1rem;">← Back to home</a>
</div>
<?php get_footer(); ?> 