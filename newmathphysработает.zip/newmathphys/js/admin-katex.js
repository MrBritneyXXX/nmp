(function($) {
    'use strict';

    // Конфигурация KaTeX
    const katexConfig = {
        delimiters: [
            {left: "$$", right: "$$", display: true},
            {left: "$", right: "$", display: false},
            {left: "\\[", right: "\\]", display: true},
            {left: "\\(", right: "\\)", display: false}
        ],
        throwOnError: false,
        trust: true,
        output: 'html',
        strict: false
    };

    // Дебаунсинг для оптимизации производительности
    function debounce(func, wait) {
        let timeout;
        return function executedFunction(...args) {
            const later = () => {
                clearTimeout(timeout);
                func(...args);
            };
            clearTimeout(timeout);
            timeout = setTimeout(later, wait);
        };
    }

    // Безопасный рендеринг KaTeX
    function safeRenderMath() {
        try {
            const editorFrame = document.getElementById('content_ifr');
            if (!editorFrame || !editorFrame.contentDocument) {
                return;
            }

            const editorBody = editorFrame.contentDocument.body;
            if (typeof renderMathInElement === 'function' && editorBody) {
                renderMathInElement(editorBody, katexConfig);
            }
        } catch (error) {
            console.warn('KaTeX admin rendering error:', error);
        }
    }

    // Оптимизированный рендеринг с дебаунсингом
    const debouncedRender = debounce(safeRenderMath, 250);

    // Инициализация в редакторе TinyMCE
    $(document).on('tinymce-editor-init', function(event, editor) {
        editor.on('change', debouncedRender);
        editor.on('keyup', debouncedRender);
    });

    // Инициализация при загрузке страницы
    $(document).ready(function() {
        // Начальный рендеринг
        safeRenderMath();

        // Наблюдатель за изменениями в редакторе
        const editorFrame = document.getElementById('content_ifr');
        if (editorFrame && editorFrame.contentDocument) {
            const observer = new MutationObserver(debouncedRender);
            observer.observe(editorFrame.contentDocument.body, {
                childList: true,
                subtree: true,
                characterData: true
            });
        }
    });

    document.addEventListener('DOMContentLoaded', function() {
        // Initialize KaTeX in the admin panel
        const content = document.querySelector('#content');
        if (content) {
            renderMathInElement(content, {
                delimiters: [
                    {left: '$$', right: '$$', display: true},
                    {left: '$', right: '$', display: false},
                    {left: '\\(', right: '\\)', display: false},
                    {left: '\\[', right: '\\]', display: true}
                ],
                throwOnError: false
            });
        }

        // Add KaTeX button to the editor toolbar
        if (typeof tinymce !== 'undefined') {
            tinymce.PluginManager.add('katex', function(editor, url) {
                editor.addButton('katex', {
                    title: 'Insert Math Formula',
                    icon: 'math',
                    onclick: function() {
                        editor.windowManager.open({
                            title: 'Insert Math Formula',
                            body: [{
                                type: 'textbox',
                                name: 'formula',
                                label: 'LaTeX Formula',
                                multiline: true,
                                minWidth: 300,
                                minHeight: 100
                            }],
                            onsubmit: function(e) {
                                const formula = e.data.formula;
                                const displayMode = formula.includes('\n');
                                const wrapper = displayMode ? '$$' : '$';
                                editor.insertContent(wrapper + formula + wrapper);
                            }
                        });
                    }
                });
            });
        }

        // Add KaTeX preview to the editor
        const editor = document.querySelector('#content');
        if (editor) {
            const preview = document.createElement('div');
            preview.className = 'katex-preview';
            preview.style.marginTop = '10px';
            preview.style.padding = '10px';
            preview.style.border = '1px solid #ddd';
            preview.style.borderRadius = '4px';
            preview.style.backgroundColor = '#f8f9fa';
            
            editor.parentNode.insertBefore(preview, editor.nextSibling);

            function updatePreview() {
                const content = editor.value;
                const mathRegex = /\$\$(.*?)\$\$|\$(.*?)\$|\\\((.*?)\\\)|\\\[(.*?)\\\]/g;
                let match;
                let previewContent = content;

                while ((match = mathRegex.exec(content)) !== null) {
                    const formula = match[1] || match[2] || match[3] || match[4];
                    try {
                        const rendered = katex.renderToString(formula, {
                            displayMode: match[0].startsWith('$$') || match[0].startsWith('\\['),
                            throwOnError: false
                        });
                        previewContent = previewContent.replace(match[0], rendered);
                    } catch (e) {
                        console.error('KaTeX error:', e);
                    }
                }

                preview.innerHTML = previewContent;
            }

            editor.addEventListener('input', updatePreview);
            updatePreview();
        }
    });

})(jQuery); 