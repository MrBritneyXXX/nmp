document.addEventListener('DOMContentLoaded', function() {
    'use strict';

    // Плавная прокрутка для якорных ссылок
    document.querySelectorAll('a[href*="#"]:not([href="#"])').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            const targetId = this.getAttribute('href');
            const targetElement = document.querySelector(targetId);
            
            if (targetElement) {
                targetElement.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });

    // Анимация появления элементов при прокрутке
    function animateOnScroll() {
        const elements = document.querySelectorAll('.post-card');
        const viewportHeight = window.innerHeight;
        const scrollTop = window.scrollY;

        elements.forEach(element => {
            const elementTop = element.getBoundingClientRect().top + scrollTop;
            const elementBottom = elementTop + element.offsetHeight;

            if (elementBottom > scrollTop && elementTop < scrollTop + viewportHeight) {
                element.classList.add('visible');
            }
        });
    }

    // Запускаем анимацию при загрузке и прокрутке
    window.addEventListener('load', animateOnScroll);
    window.addEventListener('scroll', animateOnScroll);

    // Мобильное меню
    const menuToggle = document.querySelector('.menu-toggle');
    const navMenu = document.querySelector('.nav-menu');
    const mainNavigation = document.querySelector('.main-navigation');

    if (menuToggle && navMenu) {
        menuToggle.addEventListener('click', function() {
            navMenu.classList.toggle('active');
        });
    }

    // Закрытие мобильного меню при клике вне его
    document.addEventListener('click', function(e) {
        if (mainNavigation && !mainNavigation.contains(e.target)) {
            navMenu.classList.remove('active');
        }
    });
}); 