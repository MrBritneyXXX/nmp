(function() {
    'use strict';

    // Конфигурация KaTeX
    const katexConfig = {
        delimiters: [
            {left: "$$", right: "$$", display: true},
            {left: "$", right: "$", display: false},
            {left: "\\[", right: "\\]", display: true},
            {left: "\\(", right: "\\)", display: false}
        ],
        throwOnError: false,
        trust: true,
        output: 'html',
        strict: false
    };

    // Функция для безопасного рендеринга
    function safeRenderMath() {
        try {
            if (typeof renderMathInElement === 'function') {
                renderMathInElement(document.body, katexConfig);
            }
        } catch (error) {
            console.warn('KaTeX rendering error:', error);
        }
    }

    // Инициализация при загрузке DOM
    if (document.readyState === 'loading') {
        document.addEventListener('DOMContentLoaded', safeRenderMath);
    } else {
        safeRenderMath();
    }

    // Повторный рендеринг при динамической загрузке контента
    const observer = new MutationObserver(function(mutations) {
        mutations.forEach(function(mutation) {
            if (mutation.addedNodes.length) {
                safeRenderMath();
            }
        });
    });

    observer.observe(document.body, {
        childList: true,
        subtree: true
    });

    document.addEventListener('DOMContentLoaded', function() {
        // Initialize KaTeX auto-render
        renderMathInElement(document.body, {
            delimiters: [
                {left: '$$', right: '$$', display: true},
                {left: '$', right: '$', display: false},
                {left: '\\(', right: '\\)', display: false},
                {left: '\\[', right: '\\]', display: true}
            ],
            throwOnError: false
        });

        // Add copy button to math blocks
        document.querySelectorAll('.katex-display').forEach(function(block) {
            const button = document.createElement('button');
            button.className = 'copy-math-btn';
            button.innerHTML = '<i class="fas fa-copy"></i>';
            button.title = 'Copy formula';
            
            button.addEventListener('click', function() {
                const math = block.querySelector('.katex-mathml');
                if (math) {
                    const text = math.textContent;
                    navigator.clipboard.writeText(text).then(function() {
                        button.innerHTML = '<i class="fas fa-check"></i>';
                        setTimeout(function() {
                            button.innerHTML = '<i class="fas fa-copy"></i>';
                        }, 2000);
                    });
                }
            });
            
            block.style.position = 'relative';
            block.appendChild(button);
        });
    });
})(); 