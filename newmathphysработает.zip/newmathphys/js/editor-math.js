(function() {
    tinymce.create('tinymce.plugins.mathsymbols', {
        init: function(ed, url) {
            ed.addButton('mathsymbols', {
                title: 'Вставить математический символ',
                icon: 'math',
                onclick: function() {
                    ed.windowManager.open({
                        title: 'Вставить математический символ',
                        body: [{
                            type: 'container',
                            html: '<div class="math-symbols-grid">' +
                                  '<button class="math-symbol" data-symbol="∫">∫</button>' +
                                  '<button class="math-symbol" data-symbol="∑">∑</button>' +
                                  '<button class="math-symbol" data-symbol="∏">∏</button>' +
                                  '<button class="math-symbol" data-symbol="√">√</button>' +
                                  '<button class="math-symbol" data-symbol="∞">∞</button>' +
                                  '<button class="math-symbol" data-symbol="±">±</button>' +
                                  '<button class="math-symbol" data-symbol="×">×</button>' +
                                  '<button class="math-symbol" data-symbol="÷">÷</button>' +
                                  '<button class="math-symbol" data-symbol="≤">≤</button>' +
                                  '<button class="math-symbol" data-symbol="≥">≥</button>' +
                                  '<button class="math-symbol" data-symbol="≠">≠</button>' +
                                  '<button class="math-symbol" data-symbol="≈">≈</button>' +
                                  '<button class="math-symbol" data-symbol="∂">∂</button>' +
                                  '<button class="math-symbol" data-symbol="∇">∇</button>' +
                                  '<button class="math-symbol" data-symbol="∆">∆</button>' +
                                  '<button class="math-symbol" data-symbol="∝">∝</button>' +
                                  '<button class="math-symbol" data-symbol="∈">∈</button>' +
                                  '<button class="math-symbol" data-symbol="∉">∉</button>' +
                                  '<button class="math-symbol" data-symbol="⊂">⊂</button>' +
                                  '<button class="math-symbol" data-symbol="⊃">⊃</button>' +
                                  '<button class="math-symbol" data-symbol="∪">∪</button>' +
                                  '<button class="math-symbol" data-symbol="∩">∩</button>' +
                                  '<button class="math-symbol" data-symbol="∅">∅</button>' +
                                  '<button class="math-symbol" data-symbol="∀">∀</button>' +
                                  '<button class="math-symbol" data-symbol="∃">∃</button>' +
                                  '<button class="math-symbol" data-symbol="∄">∄</button>' +
                                  '<button class="math-symbol" data-symbol="∴">∴</button>' +
                                  '<button class="math-symbol" data-symbol="∵">∵</button>' +
                                  '<button class="math-symbol" data-symbol="α">α</button>' +
                                  '<button class="math-symbol" data-symbol="β">β</button>' +
                                  '<button class="math-symbol" data-symbol="γ">γ</button>' +
                                  '<button class="math-symbol" data-symbol="δ">δ</button>' +
                                  '<button class="math-symbol" data-symbol="ε">ε</button>' +
                                  '<button class="math-symbol" data-symbol="θ">θ</button>' +
                                  '<button class="math-symbol" data-symbol="λ">λ</button>' +
                                  '<button class="math-symbol" data-symbol="μ">μ</button>' +
                                  '<button class="math-symbol" data-symbol="π">π</button>' +
                                  '<button class="math-symbol" data-symbol="σ">σ</button>' +
                                  '<button class="math-symbol" data-symbol="φ">φ</button>' +
                                  '<button class="math-symbol" data-symbol="ω">ω</button>' +
                                  '</div>'
                        }],
                        onsubmit: function(e) {
                            // Обработка выбора символа
                            var selectedSymbol = e.data.selectedSymbol;
                            if (selectedSymbol) {
                                ed.insertContent(selectedSymbol);
                            }
                        }
                    });

                    // Добавляем обработчики для кнопок символов
                    setTimeout(function() {
                        var buttons = document.querySelectorAll('.math-symbol');
                        buttons.forEach(function(button) {
                            button.addEventListener('click', function() {
                                var symbol = this.getAttribute('data-symbol');
                                ed.insertContent(symbol);
                                ed.windowManager.close();
                            });
                        });
                    }, 100);
                }
            });
        },
        createControl: function(n, cm) {
            return null;
        },
        getInfo: function() {
            return {
                longname: 'Math Symbols',
                author: 'NewMathPhys',
                version: '1.0'
            };
        }
    });
    tinymce.PluginManager.add('mathsymbols', tinymce.plugins.mathsymbols);
})(); 