document.addEventListener('DOMContentLoaded', function() {
    const editor = document.querySelector('.markdown-editor');
    const preview = document.querySelector('.markdown-preview');
    
    if (!editor || !preview) return;

    // Configure marked options
    marked.setOptions({
        breaks: true,
        gfm: true,
        headerIds: true,
        mangle: false
    });

    // Add KaTeX support to marked
    const renderer = new marked.Renderer();
    const originalCodeRenderer = renderer.code.bind(renderer);
    
    renderer.code = function(code, language) {
        if (language === 'math') {
            try {
                return katex.renderToString(code, {
                    displayMode: true,
                    throwOnError: false
                });
            } catch (e) {
                console.error('KaTeX error:', e);
                return code;
            }
        }
        return originalCodeRenderer(code, language);
    };

    // Update preview when editor content changes
    function updatePreview() {
        const content = editor.value;
        const html = marked(content, { renderer: renderer });
        preview.innerHTML = html;

        // Re-render math in preview
        renderMathInElement(preview, {
            delimiters: [
                {left: '$$', right: '$$', display: true},
                {left: '$', right: '$', display: false},
                {left: '\\(', right: '\\)', display: false},
                {left: '\\[', right: '\\]', display: true}
            ],
            throwOnError: false
        });
    }

    // Add toolbar buttons
    const toolbar = document.createElement('div');
    toolbar.className = 'markdown-toolbar';
    toolbar.innerHTML = `
        <button type="button" data-action="bold"><i class="fas fa-bold"></i></button>
        <button type="button" data-action="italic"><i class="fas fa-italic"></i></button>
        <button type="button" data-action="heading"><i class="fas fa-heading"></i></button>
        <button type="button" data-action="link"><i class="fas fa-link"></i></button>
        <button type="button" data-action="image"><i class="fas fa-image"></i></button>
        <button type="button" data-action="math"><i class="fas fa-square-root-alt"></i></button>
        <button type="button" data-action="code"><i class="fas fa-code"></i></button>
    `;

    editor.parentNode.insertBefore(toolbar, editor);

    // Handle toolbar button clicks
    toolbar.addEventListener('click', function(e) {
        const button = e.target.closest('button');
        if (!button) return;

        const action = button.dataset.action;
        const selection = {
            start: editor.selectionStart,
            end: editor.selectionEnd,
            text: editor.value.substring(editor.selectionStart, editor.selectionEnd)
        };

        let replacement = '';
        switch (action) {
            case 'bold':
                replacement = `**${selection.text}**`;
                break;
            case 'italic':
                replacement = `*${selection.text}*`;
                break;
            case 'heading':
                replacement = `## ${selection.text}`;
                break;
            case 'link':
                replacement = `[${selection.text}](url)`;
                break;
            case 'image':
                replacement = `![${selection.text}](image-url)`;
                break;
            case 'math':
                replacement = `$$${selection.text}$$`;
                break;
            case 'code':
                replacement = '```\n' + selection.text + '\n```';
                break;
        }

        editor.value = editor.value.substring(0, selection.start) + 
                      replacement + 
                      editor.value.substring(selection.end);
        
        editor.focus();
        updatePreview();
    });

    // Update preview on input
    editor.addEventListener('input', updatePreview);

    // Initial preview update
    updatePreview();
}); 